package com.tts.bakeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BakeshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(BakeshopApplication.class, args);
	}

}
