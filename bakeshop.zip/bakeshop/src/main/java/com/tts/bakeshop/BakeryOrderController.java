package com.tts.bakeshop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class BakeryOrderController 
{
    @Autowired 
    BakeryOrderRepository orderrepository;

    @GetMapping(value="/") /* http://localhost:8080/ */
    String mainPage(Model model)
    {
        model.addAttribute("bakeryorderrepository", orderrepository);
        return "index";
    }

    @GetMapping(value="/bakeryorder") /* http://localhost:8080/bakeryorder */
    String bakeryOrder()
    {
        return "bakeryorder";
    }

    @PostMapping(value="/orderform") /* http://localhost:8080/orderform */
    String orderForm(Model model)
    {
        model.addAttribute("info",
                           "The name is:"
                           + orderrepository.getPastry()
                           + "and the comment is: "
                           + orderrepository.getComment());
        
        return "bakeryorder";
    }

}
